﻿namespace SchoolDashBoard.DTO;
public class SubjectDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}
