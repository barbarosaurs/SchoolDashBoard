export interface Teacher {
  id: number;
  firstName: string;
  lastName: string;
  teacherCode: string;
}

