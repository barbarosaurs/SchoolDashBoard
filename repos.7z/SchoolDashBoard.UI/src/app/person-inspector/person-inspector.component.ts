import { Component } from '@angular/core';

@Component({
  selector: 'app-person-inspector',
  standalone: true,
  imports: [],
  templateUrl: './person-inspector.component.html',
  styleUrl: './person-inspector.component.scss'
})
export class PersonInspectorComponent {

}
